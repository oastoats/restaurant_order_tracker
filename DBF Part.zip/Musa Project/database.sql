CREATE TABLE restaurants (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('customer', 'staff')),
  restaurant_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE SET NULL
);

CREATE TABLE orders (
  id SERIAL PRIMARY KEY,
  customer_id INT NOT NULL,
  staff_id INT NOT NULL,
  restaurant_id INT NOT NULL,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'ready', 'collected')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  rating SMALLINT NULL CHECK (rating IN (0, 1)),

  FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (staff_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE
);

INSERT INTO restaurants (name) VALUES 
('Pizza Hut'),
('KFC'),
('McDonalds');

INSERT INTO users (username, password, role, restaurant_id) VALUES 
('john_staff', 'password123', 'staff', 1),
('jane_staff', 'password123', 'staff', 2),
('alice_cust', 'password123', 'customer', NULL),
('bob_cust', 'password123', 'customer', NULL);