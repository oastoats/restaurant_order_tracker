CREATE DATABASE IF NOT EXISTS order_tracker;
USE order_tracker;

CREATE TABLE `restaurants` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('customer', 'staff') NOT NULL,
  `restaurant_id` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants`(`id`) ON DELETE SET NULL
);

CREATE TABLE `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT NOT NULL,
  `staff_id` INT NOT NULL,
  `restaurant_id` INT NOT NULL,
  `status` ENUM('pending', 'ready', 'collected') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `rating` TINYINT(1) NULL COMMENT '1 for thumbs up, 0 for thumbs down',
  FOREIGN KEY (`customer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`staff_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`restaurant_id`) REFERENCES `restaurants`(`id`) ON DELETE CASCADE
);

-- Dummy Data for initial testing
INSERT INTO `restaurants` (`name`) VALUES 
('Pizza Hut'),
('KFC'),
('McDonalds');

INSERT INTO `users` (`username`, `password`, `role`, `restaurant_id`) VALUES 
('john_staff', 'password123', 'staff', 1),
('jane_staff', 'password123', 'staff', 2),
('alice_cust', 'password123', 'customer', NULL),
('bob_cust', 'password123', 'customer', NULL);
